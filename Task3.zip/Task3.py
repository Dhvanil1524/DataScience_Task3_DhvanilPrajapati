#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np


A = np.array([[4, 1], 
              [2, 3]])


eigenvalues, eigenvectors = np.linalg.eig(A)


D = np.diag(eigenvalues)
P = eigenvectors

P_inv = np.linalg.inv(P)

print("Original Matrix (A):")
print(A)
print("\nDiagonal Matrix (D):")
print(D)
print("\nEigenvector Matrix (P):")
print(P)
print("\nInverse of Eigenvector Matrix (P⁻¹):")
print(P_inv)


reconstructed_A = P @ D @ P_inv
print("\nReconstructed Matrix (P * D * P⁻¹):")
print(reconstructed_A)


# In[ ]:




